<script setup>
import { ref, onMounted } from 'vue';

const showBanner = ref(false);

onMounted(() => {
  showBanner.value = !localStorage.getItem('cookiesAccepted');
});

function acceptCookies() {
  localStorage.setItem('cookiesAccepted', '1');
  showBanner.value = false;
}
</script>

<template>
  <div v-if="showBanner" class="fixed bottom-0 left-0 w-full bg-gray-900 text-white p-4 flex flex-col md:flex-row items-center justify-between z-50">
    <span class="mb-2 md:mb-0">Este sitio utiliza cookies <!-- <a href="/politica-cookies" class="underline">Más información</a> --></span>
    <button @click="acceptCookies" class="bg-green-600 px-4 py-2 rounded ml-0 md:ml-4 mt-2 md:mt-0">Aceptar</button>
  </div>
</template>