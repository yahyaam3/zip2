<script setup>
import { Head, Link, router } from '@inertiajs/vue3';
import { ref, defineProps, computed } from 'vue';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

// Cambia 'categories' por el nombre de tu recurso si es necesario
const props = defineProps({
    categories: Array // igual que en ListProduct
});

// Buscador reactivo igual que productos
const search = ref('');
const filteredCategories = computed(() =>
  props.categories.filter(category =>
    category.name.toLowerCase().includes(search.value.toLowerCase())
  )
);

// Eliminar igual que productos
function eliminar(id){
    if (window.confirm('¿Seguro que deseas eliminar esta categoría?')) {
        router.delete(route('category.destroy', id))
    }
}
</script>
<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-3xl w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Categorías</h1>
        <label for="search-category" class="block text-gray-800 font-semibold mb-1">Buscar categoría</label>
        <input
          id="search-category"
          type="text"
          v-model="search"
          placeholder="Buscar por nombre"
          class="w-full px-3 py-2 border border-gray-400 rounded mb-4 focus:ring-2 focus:ring-blue-600 focus:outline-none"
          aria-label="Buscar categorías"
        />
        <div class="overflow-x-auto rounded shadow bg-white">
          <table class="w-full text-left border border-gray-300 text-sm" aria-label="Tabla de categorías">
            <thead class="bg-gray-200">
              <tr>
                <th class="p-2 border-b border-gray-300">Nombre</th>
                <th class="p-2 border-b border-gray-300">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="category in filteredCategories" :key="category.id" class="hover:bg-gray-50 focus-within:bg-blue-50">
                <td class="p-2 border-b border-gray-200 text-gray-900">{{ category.name }}</td>
                <td class="p-2 border-b border-gray-200">
                  <div class="flex flex-wrap gap-1">
                    <Link
                      :href="route('category.show', category.id)"
                      class="px-2 py-1 rounded bg-blue-800 text-white hover:bg-blue-900 focus:ring-2 focus:ring-blue-400"
                      aria-label="Ver categoría"
                    >Ver</Link>
                    <Link
                      :href="route('category.edit', category.id)"
                      class="px-2 py-1 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400"
                      aria-label="Editar categoría"
                    >Editar</Link>
                    <button
                      @click="eliminar(category.id)"
                      class="px-2 py-1 rounded bg-red-700 text-white hover:bg-red-800 focus:ring-2 focus:ring-red-400"
                      aria-label="Eliminar categoría"
                      type="button"
                    >Eliminar</button>
                  </div>
                </td>
              </tr>
              <tr v-if="filteredCategories.length === 0">
                <td colspan="2" class="p-2 text-center text-gray-500">No hay categorías</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
          <Link :href="route('category.create')" class="px-4 py-2 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400" aria-label="Crear nueva categoría">
            Crear Categoría
          </Link>
          <Link :href="route('home')" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400" aria-label="Volver al inicio">
            Volver
          </Link>
        </div>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>