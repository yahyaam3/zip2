<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-lg w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Crear Anuncio</h1>
        <form @submit.prevent="submit" class="bg-white p-4 border rounded space-y-4">
          <div>
            <label for="name" class="block mb-1 font-semibold text-gray-800">Título</label>
            <input
              id="name"
              v-model="form.name"
              type="text"
              required
              class="w-full border border-gray-400 rounded px-3 py-2"
            />
          </div>
          <div>
            <label for="description" class="block mb-1 font-semibold text-gray-800">Descripción</label>
            <input
              id="description"
              v-model="form.description"
              type="text"
              required
              class="w-full border border-gray-400 rounded px-3 py-2"
            />
          </div>
          <div>
            <label for="email" class="block mb-1 font-semibold text-gray-800">Email de contacto</label>
            <input
              id="email"
              v-model="form.email"
              type="email"
              required
              class="w-full border border-gray-400 rounded px-3 py-2"
            />
          </div>
          <div>
            <label for="category_id" class="block mb-1 font-semibold text-gray-800">Categoría</label>
            <select
              id="category_id"
              name="category_id"
              v-model="form.category_id"
              required
              class="w-full border border-gray-400 rounded px-3 py-2"
            >
              <option value="" disabled>Selecciona una categoría</option>
              <option v-for="category in categories" :key="category.id" :value="category.id">
                {{ category.name }}
              </option>
            </select>
          </div>
          <div class="flex flex-wrap gap-2 justify-between mt-4">
            <Link :href="route('product.index')" class="bg-gray-700 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400">
              Cancelar
            </Link>
            <button
              type="submit"
              class="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800 focus:ring-2 focus:ring-green-400"
            >
              Crear
            </button>
          </div>
        </form>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>

<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const props = defineProps({
    categories: Array,
});

const form = useForm({
    name: '',
    description: '',
    email: '',
    category_id: '',
});

function submit() {
    form.post(route('product.store'));
}
</script>