<script setup>
import { Head, Link, router } from '@inertiajs/vue3';
import { ref, defineProps, watch } from 'vue';
import axios from 'axios';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const props = defineProps({
    products: Object, // paginator
    categories: Array,
    filters: Object,
});

const products = ref(props.products.data || []);
const pagination = ref(props.products);
const category_id = ref(props.filters.category_id || '');
const search = ref(props.filters.search || '');
const perPage = ref(props.filters.per_page || 5);

async function fetchProducts(page = 1) {
    const response = await axios.get(route('product.index'), {
        params: {
            category_id: category_id.value,
            search: search.value,
            per_page: perPage.value,
            page,
        }
    });
    products.value = response.data.products.data;
    pagination.value = response.data.products;
}

watch([category_id, search, perPage], () => fetchProducts(1));

// Acciones
function eliminar(id){
    if (window.confirm('¿Seguro que deseas eliminar este anuncio?')) {
        router.delete(route('product.destroy', id), {
            onSuccess: () => fetchProducts(pagination.value.current_page)
        });
    }
}
</script>
<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-3xl w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Anuncios</h1>
        <label for="search-product" class="block text-gray-800 font-semibold mb-1">Buscar anuncio</label>
        <div class="flex flex-wrap gap-2 mb-4">
          <select v-model="category_id" class="border rounded px-2 py-1" aria-label="Filtrar por categoría">
            <option value="">Todos los clasificados</option>
            <option v-for="cat in props.categories" :key="cat.id" :value="cat.id">{{ cat.name }}</option>
          </select>
          <input
            id="search-product"
            type="text"
            v-model="search"
            placeholder="Buscar por título o descripción"
            class="px-3 py-2 border border-gray-400 rounded"
            aria-label="Buscar anuncios"
          />
          <select v-model="perPage" class="border rounded px-2 py-1" aria-label="Elementos por página">
            <option value="5">5</option>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="50">50</option>
          </select>
        </div>
        <div class="overflow-x-auto rounded shadow bg-white">
          <table class="w-full text-left border border-gray-300 text-sm" aria-label="Tabla de anuncios">
            <thead class="bg-gray-200">
              <tr>
                <th class="p-2 border-b border-gray-300">Título</th>
                <th class="p-2 border-b border-gray-300">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="product in products" :key="product.id" class="hover:bg-gray-50 focus-within:bg-blue-50">
                <td class="p-2 border-b border-gray-200 text-gray-900">
                  {{ product.name }}
                </td>
                <td class="p-2 border-b border-gray-200">
                  <div class="flex flex-wrap gap-1">
                    <Link
                      :href="route('product.show', product.id)"
                      class="px-2 py-1 rounded bg-blue-800 text-white hover:bg-blue-900 focus:ring-2 focus:ring-blue-400"
                      aria-label="Ver anuncio"
                    >Ver</Link>
                    <Link
                      :href="route('product.edit', product.id)"
                      class="px-2 py-1 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400"
                      aria-label="Editar anuncio"
                    >Editar</Link>
                    <button
                      @click="eliminar(product.id)"
                      class="px-2 py-1 rounded bg-red-700 text-white hover:bg-red-800 focus:ring-2 focus:ring-red-400"
                      aria-label="Eliminar anuncio"
                      type="button"
                    >Eliminar</button>
                  </div>
                </td>
              </tr>
              <tr v-if="products.length === 0">
                <td colspan="2" class="p-2 text-center text-gray-500">No hay anuncios</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- Paginación -->
        <div class="flex justify-center items-center gap-2 mt-4">
          <button
            v-if="pagination.current_page > 1"
            @click="fetchProducts(pagination.current_page - 1)"
            class="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400"
          >Anterior</button>
          <span>Página {{ pagination.current_page }} de {{ pagination.last_page }}</span>
          <button
            v-if="pagination.current_page < pagination.last_page"
            @click="fetchProducts(pagination.current_page + 1)"
            class="px-3 py-1 rounded bg-gray-300 hover:bg-gray-400"
          >Siguiente</button>
        </div>
        <div class="flex flex-wrap gap-2 mt-4">
          <Link :href="route('product.create')" class="px-4 py-2 rounded bg-green-700 text-white hover:bg-green-800 focus:ring-2 focus:ring-green-400" aria-label="Crear nuevo anuncio">
            Crear Anuncio
          </Link>
          <Link :href="route('home')" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400" aria-label="Volver al inicio">
            Volver
          </Link>
        </div>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>