<script setup>
import { Head } from '@inertiajs/vue3';
import { ref, onMounted, onBeforeUnmount, defineProps, computed } from 'vue';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

// Accept products and categories from backend
const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    products: Array,
    categories: Array,
});

// Carousels
const products = ref(props.products);
const imageList = ref([
    '/images/image1.jpg',
    '/images/image2.jpg',
    '/images/image3.jpg'
]);
const currentProduct = ref(0);
let productInterval = null;
const currentImage = ref(0);
let imageInterval = null;

onMounted(() => {
    productInterval = setInterval(() => nextProduct(), 2000);
    imageInterval = setInterval(() => nextImage(), 2500);
});
onBeforeUnmount(() => {
    clearInterval(productInterval);
    clearInterval(imageInterval);
});
function nextProduct() {
    if (products.value.length)
        currentProduct.value = (currentProduct.value + 1) % products.value.length;
}
function prevProduct() {
    if (products.value.length)
        currentProduct.value = (currentProduct.value - 1 + products.value.length) % products.value.length;
}
function nextImage() {
    currentImage.value = (currentImage.value + 1) % imageList.value.length;
}
function prevImage() {
    currentImage.value = (currentImage.value - 1 + imageList.value.length) % imageList.value.length;
}

// Tabs and search logic
const activeTab = ref('products');
const searchProducts = ref('');
const searchCategories = ref('');
const selectedCategory = ref('');

const filteredProducts = computed(() =>
    products.value.filter(product =>
        (
            (!selectedCategory.value || (product.category && product.category.id == selectedCategory.value))
        ) &&
        (
            (product.name && product.name.toLowerCase().includes(searchProducts.value.toLowerCase())) ||
            (product.description && product.description.toLowerCase().includes(searchProducts.value.toLowerCase())) ||
            (product.email && product.email.toLowerCase().includes(searchProducts.value.toLowerCase())) ||
            (product.category && product.category.name && product.category.name.toLowerCase().includes(searchProducts.value.toLowerCase()))
        )
    )
);
const filteredCategories = computed(() =>
    props.categories.filter(category =>
        (category.name && category.name.toLowerCase().includes(searchCategories.value.toLowerCase()))
    )
);
</script>

<template>
  <NavbarLayout>
    <main class="flex-1 flex flex-col items-center justify-center gap-8 py-12 bg-gray-50 min-h-screen">
      <div class="w-full max-w-lg text-center mb-8">
        <img src="/images/logo.png" alt="Logo" class="mx-auto mb-4 w-24 h-24" />
        <h1 class="text-3xl font-bold mb-2">Bienvenido a la página de anuncios</h1>
        <p class="mb-4 text-gray-700">Publica y encuentra anuncios clasificados de cualquier categoría.</p>
        <div class="flex justify-center gap-4">
        </div>
      </div>

      <!-- Product Info Carousel -->
      <div class="w-full max-w-md text-center mb-8">
        <h2 class="text-xl font-semibold mb-4">Anuncios</h2>
        <div class="bg-white rounded shadow p-8 min-h-[120px] flex flex-col items-center justify-center transition-all duration-300">
          <template v-if="products.length">
            <div class="text-2xl font-bold mb-2">
              {{ products[currentProduct].name }}
            </div>
            <div class="text-gray-700 mb-1">
              {{ products[currentProduct].description }}
            </div>
            <div class="text-lg text-blue-700 font-semibold mb-1">
              {{ products[currentProduct].email }}
            </div>
            <div class="text-sm text-gray-500">
              Categoría: {{ products[currentProduct].category?.name || 'Sin categoría' }}
            </div>
          </template>
          <span v-else>No hay anuncios</span>
        </div>
        <div class="flex justify-center gap-4 mt-4">
          <button @click="prevProduct" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">&lt;</button>
          <button @click="nextProduct" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">&gt;</button>
        </div>
      </div>

      <!-- Image Carousel -->
      <div class="w-full max-w-md text-center mb-8">
        <h2 class="text-xl font-semibold mb-4">Galería</h2>
        <div class="relative h-64 flex items-center justify-center bg-white rounded shadow">
          <img
            :src="imageList[currentImage]"
            alt="Imagen de galería"
            class="object-contain h-full w-full rounded transition-all duration-300"
          />
        </div>
        <div class="flex justify-center gap-4 mt-4">
          <button @click="prevImage" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">&lt;</button>
          <button @click="nextImage" class="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300">&gt;</button>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-4 mb-8">
        <button
          :class="activeTab === 'products' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'"
          class="px-4 py-2 rounded"
          @click="activeTab = 'products'"
        >Anuncios</button>
        <button
          :class="activeTab === 'categories' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'"
          class="px-4 py-2 rounded"
          @click="activeTab = 'categories'"
        >Categorías</button>
      </div>

      <!-- Products Table -->
      <section
        v-show="activeTab === 'products'"
        aria-label="Lista de Anuncios"
        class="bg-white p-4 border rounded mb-8 w-full max-w-3xl"
      >
        <div class="mb-4 flex flex-col sm:flex-row gap-2" role="search">
          <select
            v-model="selectedCategory"
            class="px-4 py-2 border rounded-lg shadow-sm w-full sm:w-auto"
            aria-label="Filtrar por categoría"
          >
            <option value="">Todas las categorías</option>
            <option v-for="cat in props.categories" :key="cat.id" :value="cat.id">
              {{ cat.name }}
            </option>
          </select>
          <input
            id="product-search"
            type="text"
            v-model="searchProducts"
            placeholder="Buscar por título, descripción, email o categoría..."
            class="w-full px-4 py-2 border rounded-lg shadow-sm"
            aria-label="Buscar anuncios"
          />
        </div>
        <div class="overflow-x-auto" role="region" aria-label="Tabla de anuncios">
          <table class="w-full border min-w-[600px]" role="grid">
            <thead>
              <tr class="bg-gray-400 text-left">
                <th class="p-2 border border-black">Título</th>
                <th class="p-2 border border-black">Descripción</th>
                <th class="p-2 border border-black">Email</th>
                <th class="p-2 border border-black">Categoría</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="product in filteredProducts" :key="product.id">
                <td class="p-2 border border-black">{{ product.name }}</td>
                <td class="p-2 border border-black">{{ product.description }}</td>
                <td class="p-2 border border-black">{{ product.email }}</td>
                <td class="p-2 border border-black">{{ product.category?.name || 'Sin categoría' }}</td>
              </tr>
              <tr v-if="filteredProducts.length === 0">
                <td colspan="4" class="p-2 text-center text-gray-500">No hay anuncios</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- Categories Table -->
      <section
        v-show="activeTab === 'categories'"
        aria-label="Lista de Categorías"
        class="bg-white p-4 border rounded mb-8 w-full max-w-2xl"
      >
        <div class="mb-4" role="search">
          <label for="category-search" class="sr-only">Buscar categorías</label>
          <input
            id="category-search"
            type="text"
            v-model="searchCategories"
            placeholder="Buscar por nombre..."
            class="w-full px-4 py-2 border rounded-lg shadow-sm"
            aria-label="Buscar categorías"
          />
        </div>
        <div class="overflow-x-auto" role="region" aria-label="Tabla de categorías">
          <table class="w-full border min-w-[400px]" role="grid">
            <thead>
              <tr class="bg-gray-400 text-left">
                <th class="p-2 border border-black">Nombre</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="category in filteredCategories" :key="category.id">
                <td class="p-2 border border-black">{{ category.name }}</td>
              </tr>
              <tr v-if="filteredCategories.length === 0">
                <td class="p-2 text-center text-gray-500">No hay categorías</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </main>
    <FooterLayout />
  </NavbarLayout>
</template>
