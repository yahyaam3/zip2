<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3';
import NavbarLayout from '@/Layouts/NavbarLayout.vue';
import FooterLayout from '@/Layouts/FooterLayout.vue';

const form = useForm({
    name: '',
});

function submit() {
    form.post(route('category.store'));
}
</script>

<template>
  <div class="min-h-screen flex flex-col">
    <NavbarLayout />
    <main class="flex-1 bg-gray-50">
      <div class="max-w-lg w-full mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4 text-gray-900">Crear Categoría</h1>
        <form @submit.prevent="submit" class="bg-white p-4 border rounded space-y-4">
          <div>
            <label for="name" class="block mb-1 font-semibold text-gray-800">Nombre</label>
            <input
              id="name"
              v-model="form.name"
              type="text"
              required
              class="w-full border border-gray-400 rounded px-3 py-2"
            />
          </div>
          <div class="flex flex-wrap gap-2 justify-between mt-4">
            <Link :href="route('category.index')" class="bg-gray-700 text-white px-4 py-2 rounded hover:bg-gray-900 focus:ring-2 focus:ring-gray-400">
              Cancelar
            </Link>
            <button
              type="submit"
              class="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800 focus:ring-2 focus:ring-green-400"
            >
              Crear
            </button>
          </div>
        </form>
      </div>
    </main>
    <FooterLayout />
  </div>
</template>