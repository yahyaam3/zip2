<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CategoryController extends Controller
{
    // Listar todos (cambia 'categories' si tu modelo es otro)
    public function index()
    {
        return Inertia::render('ListCategory',[
            'categories'=>Category::all() // Cambia 'Category' por tu modelo
        ]);
    }

    // Mostrar formulario de crear
    public function create()
    {
         return Inertia::render('CreateCategory');
    }

    // Guardar nuevo registro
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required | max:255', // Cambia 'name' por tus campos
        ]);

        Category::create($validate);
        return redirect()->route('category.index');
    }

    // Mostrar detalle
    public function show(Category $category)
    {
        return Inertia::render('ShowCategory',[
            'category'=>$category
        ]);
    }

    // Mostrar formulario de editar
    public function edit(Category $category)
    {
        return Inertia::render('EditCategory',[
            'category'=>$category
        ]);
    }

    // Actualizar registro
    public function update(Request $request, Category $category)
    {
        $validate = $request->validate([
            'name' => 'required | max:255', // Cambia 'name' por tus campos
        ]);

        $category->update($validate);
        return redirect()->route('category.index');
    }

    // Eliminar registro
    public function destroy(Category $category)
    {
        $category->delete();
        return redirect()->route('category.index');
    }
}