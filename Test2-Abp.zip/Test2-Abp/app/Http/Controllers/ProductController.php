<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Category;

class ProductController extends Controller
{
    // Listar productos (anuncios)
    public function index(Request $request)
    {
        // Paginación y filtro por categoría y AJAX (requisito 10, 11, 12)
        $query = Product::with('category')->orderBy('created_at', 'desc');

        if ($request->has('category_id') && $request->category_id) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->has('search') && $request->search) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $perPage = $request->input('per_page', 5); // 5, 10, 20, 50
        $products = $query->paginate($perPage);

        // AJAX para recarga dinámica
        if ($request->wantsJson()) {
            return response()->json(['products' => $products]);
        }

        return Inertia::render('ListProduct', [
            'products' => $products,
            'categories' => Category::all(),
            'filters' => [
                'category_id' => $request->category_id,
                'search' => $request->search,
                'per_page' => $perPage,
            ]
        ]);
    }

    // Formulario crear
    public function create()
    {
        return Inertia::render('CreateProduct', [
            'categories' => Category::all()
        ]);
    }

    // Guardar nuevo anuncio
    public function store(Request $request)
    {
        // Valida los campos (requisito 5)
        $validate = $request->validate([
            'name' => 'required|max:255',
            'description' => 'required|max:1000',
            'email' => 'required|email',
            'category_id' => 'required|exists:categories,id',
        ]);

        Product::create($validate);
        return redirect()->route('product.index');
    }

    // Detalle del anuncio
    public function show(Product $product)
    {
        return Inertia::render('ShowProduct', [
            'product' => $product->load('category')
        ]);
    }

    // Formulario editar
    public function edit(Product $product)
    {
        return Inertia::render('EditProduct', [
            'product' => $product,
            'categories' => Category::all()
        ]);
    }

    // Actualizar anuncio
    public function update(Request $request, Product $product)
    {
        $validate = $request->validate([
            'name' => 'required|max:255',
            'description' => 'required|max:1000',
            'email' => 'required|email',
            'category_id' => 'required|exists:categories,id',
        ]);

        // Actualiza fecha de publicación (requisito 17)
        $product->update($validate + ['updated_at' => now()]);
        return redirect()->route('product.index');
    }

    // Eliminar anuncio
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('product.index');
    }
}
