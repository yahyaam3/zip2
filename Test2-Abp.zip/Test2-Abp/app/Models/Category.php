<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    // Cambia 'name' por los campos de tu tabla
    protected $fillable = [
        'name',
    ];

    // Relación: una categoría tiene muchos productos
    public function product() {
        return $this->hasMany(Product::class);
    }
}
