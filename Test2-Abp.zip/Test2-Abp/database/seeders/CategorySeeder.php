<?php

namespace Database\Seeders;

use App\Models\Category;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/* remember to change name of seeder class */
class CategorySeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Category::insert([
            'name' => 'Vehicles',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Immobiiliaria',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Feina',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Tecnologia',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Moda i complements',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Llar i jardi',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Esports i oci',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Category::insert([
            'name' => 'Mascotes',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        Category::insert([
            'name' => 'Serveis',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        Category::insert([
            'name' => 'Altres',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}