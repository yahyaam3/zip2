<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Título del anuncio
            $table->text('description'); // Descripción del anuncio
            $table->string('email'); // Email de contacto
            $table->foreignId('category_id')->constrained()->onDelete('cascade'); // Relación con categorías
            $table->timestamps(); // created_at = fecha publicación
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
