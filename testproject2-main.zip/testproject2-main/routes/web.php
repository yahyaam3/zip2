<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\CategoryController;
use App\Models\Producto;
use App\Models\Categories;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'productos' => Producto::with('category')->get(),
        'categories' => Categories::all(),
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::resource('categories', CategoryController::class)->middleware(['auth']);
Route::resource('productos', ProductoController::class)->middleware(['auth']);

Route::put('/productos/{producto}/category', [ProductoController::class, 'updateCategory']);

Route::get('/api/categories', function() {
    return \App\Models\Categories::all();
});

require __DIR__.'/auth.php';
