<template>
    <!-- Barra de navegación superior -->
    <Navbar />
    <div class="container mx-auto px-4">
        <!-- Título principal de la página -->
        <h1 class="text-xl md:text-2xl font-bold mb-4">Editar Productos</h1>
        <div class="bg-white p-4 border rounded">
            <!-- Formulario para editar un producto -->
            <form @submit.prevent="submit" enctype="multipart/form-data" class="max-w-2xl mx-auto">
                <!-- Campo para el nombre del producto -->
                <div class="mb-3">
                    <label for="titol" class="block mb-1">Título:</label>
                    <input type="text" id="titol" v-model="form.titol" class="w-full border p-2 rounded" required />
                </div>

                <!-- Campo para la descripción del producto -->
                <div class="mb-3">
                    <label for="description" class="block mb-1">description:</label>
                    <input type="text" id="description" v-model="form.description" class="w-full border p-2 rounded" required />
                </div>  

                <!-- Campo para el número del producto -->
                <div class="mb-3">
                    <label for="mail" class="block mb-1">mail:</label>
                    <input type="text" id="mail" v-model="form.mail" class="w-full border p-2 rounded" required />
                </div> 

                <!-- Campo para la fecha -->
                <div class="mb-3">
                    <label for="date" class="block mb-1">Fecha:</label>
                    <input 
                        type="date" 
                        id="date" 
                        v-model="form.date" 
                        class="w-full border p-2 rounded"
                        required 
                        aria-required="true"
                        aria-label="Fecha"
                    />
                </div>

                <!-- Campo para la hora -->
                <div class="mb-3">
                    <label for="hora" class="block mb-1">Hora:</label>
                    <input 
                        type="time" 
                        id="hora" 
                        v-model="form.hora" 
                        class="w-full border p-2 rounded"
                        required 
                        aria-required="true"
                        aria-label="Hora"
                    />
                </div>

                <!-- Selección de la categoría del producto -->
                <div class="mb-3">
                    <label for="category_id" class="block mb-1">Categoría:</label>
                    <select
                        id="category_id"
                        v-model="form.category_id"
                        required
                        aria-required="true"
                        aria-label="Seleccionar categoría"
                        class="w-full border p-2 rounded"
                    >
                        <option value="">Seleccione una categoría</option>
                        <option v-for="category in categories" :key="category.id" :value="category.id">
                            {{ category.name }}
                        </option>
                    </select>
                </div>   

                <!-- Botones para cancelar o guardar los cambios -->
                <div class="flex flex-col md:flex-row justify-between mt-4 space-y-2 md:space-y-0">
                    <Link :href="route('productos.index')" class="w-full md:w-auto text-center bg-gray-300 px-3 py-1 rounded">
                        Cancelar
                    </Link>
                    <button type="submit" class="w-full md:w-auto bg-blue-700 text-white px-3 py-1 rounded">
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- Pie de página -->
    <Footer/>
</template>

<script setup>
// Importa los helpers de Inertia y Vue
import { Head, Link, useForm } from '@inertiajs/vue3';
import { defineProps, onMounted, ref } from 'vue';
// Importa los componentes de la barra de navegación y el pie de página
import Navbar from '@/Components/Navbar.vue';
import Footer from '@/Components/Footer.vue';

// Recibe el producto a editar y las categorías como props
const props = defineProps({
    producto: Object,
    categories: Array,
});

// Variable reactiva para la vista previa de la imagen seleccionada
const previewImage = ref(null);

// Formulario reactivo para el producto, con método PUT
const form = useForm({
    titol: '',
    description: '',
    mail: '',
    date: '',
    hora: '',
    category_id: '',
    photo: null,
    _method: 'put',
});

// Maneja el cambio de imagen y muestra la vista previa
const handleImageChange = (event) => {
    const file = event.target.files[0];
    form.photo = file;
    
    if (file) {
        previewImage.value = URL.createObjectURL(file);
    }
};

// Al montar el componente, rellena el formulario con los datos actuales del producto
onMounted(() => {
    if (props.producto) {
        form.titol = props.producto.titol;
        form.description = props.producto.description;
        form.mail = props.producto.mail;
        form.date = props.producto.date;
        form.hora = props.producto.hora;
        form.category_id = props.producto.category_id;
    }
});

// Función que se ejecuta al enviar el formulario
function submit() {
    form.post(route('productos.update', props.producto.id));
}
</script>

