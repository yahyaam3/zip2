<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Producto;
use App\Models\Categories;

class ProductoSeeder extends Seeder
{
    public function run(): void
    {
        $categories = Categories::all();
        
        if ($categories->isEmpty()) {
            $this->call(CategorySeeder::class);
            $categories = Categories::all();
        }

        $anuncis = [
            [
                'titol' => 'Anunci 1',
                'description' => 'Descripció 1',
                'mail' => 'kk@test.com',
                'date' => now(),
                'hora' => now()->format('H:i'),
                'category_id' => $categories->where('name', 'Serveis')->first()->id
            ],
            // ...más anuncios...
        ];

        foreach ($prodcuto as $producto) {
            Producto::create($producto);
        }
    }
}