<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Categories;

class ProductoController extends Controller
{
    public function index()
    {
        return Inertia::render('ListProducto', [
            'productos' => Producto::with('category')->get()
        ]);
    }

    public function create()
    {
        $categories = Categories::all();
        return Inertia::render('CreateProducto',[
            'categories' => $categories
        ]);
    }

    public function store(Request $request)
    {
        $validate = $request->validate([
            'titol'        => 'required|max:255',
            'description' => 'required|max:255',
            'date' => 'required|date',
            'hora' => 'required|date_format:H:i',
            'mail'      => 'required|email|max:255',
            'category_id' => 'required|exists:categories,id',
        ]);

        Producto::create($validate);
        return redirect()->route('productos.index');
    }

    public function show(Producto $producto)
    {
        return Inertia::render('ShowProducto', [
            'producto' => $producto->load('category')
        ]);
    }

    public function edit(Producto $producto)
    {
        return Inertia::render('EditProducto', [
            'producto' => $producto,
            'categories' => Categories::all()
        ]);
    }

    public function update(Request $request, Producto $producto)
    {
        $validate = $request->validate([
            'titol'        => 'required|max:255',
            'description' => 'required|max:255',
            'date' => 'required|date',
            'hora' => 'required|date_format:H:i',
            'mail'      => 'required|email|max:255',
            'category_id' => 'required|exists:categories,id',
        ]);

        $producto->update($validate);
        return redirect()->route('productos.index');
    }

    public function destroy(Producto $producto)
    {
        $producto->delete();
        return redirect()->route('productos.index');
    }
}