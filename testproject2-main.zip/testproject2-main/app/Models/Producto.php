<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    protected $fillable = [
        'titol',
        'description',
        'date',
        'hora',
        'mail',
        'category_id'
    ];

    public function category()
    {
        return $this->belongsTo(Categories::class);
    }
}